sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.zeiss.autoadmin.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);